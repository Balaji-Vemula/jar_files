"use strict";

window.onload=function(){
    time.onclick=hideTitle;
}
  
function reply_click(clicked_id)
{
    document.getElementById("mg").innerHTML=document.getElementById(clicked_id).innerHTML;

    var c=Date.parse("Jan 01, 2001")
    alert(c)
}
function hideTitle(){
    var x = document.getElementById("34");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
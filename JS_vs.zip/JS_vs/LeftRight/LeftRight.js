"use strict";

var x="5"+2+3;
console.log("var x=",x);

var x=2+3+"7";
console.log("var re-declared x=",x);

let z="5"+2+3;
console.log("let z=",z);

let y=2+3+"7";
console.log("let y=",y);

const a="5"+2+3;
console.log("const a=",a);

const b=2+3+"7";
console.log("const b=",b);
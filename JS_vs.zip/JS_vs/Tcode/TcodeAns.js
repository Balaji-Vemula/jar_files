function resetInputField()
{
    document.getElementById("inputNumber").value=0;

}
function calculateDeadLine()
{
    var date=new Date();//this gives the current date and time;
    var a=document.getElementById("inputNumber").value;
    a=parseInt(a,10);// 10 parameter denotes as Decimal number system (base-10) i.e, convert the string a into number of base-10
    var b=date.getDate();
    date.setDate(a+b);
    var c='Your project deadline:'+date.getDate()+"/"+(date.getMonth()+1)+'/'+date.getFullYear();
    document.getElementById("daysRemaining").innerHTML=c;
}
function resetInputField()
{
    document.getElementById("inputNumber").value='0';

}
function calculateDeadLine()
{
    var dt=new Date();

    var a=document.getElementById("inputNumber").value;
    var b=dt.getDate();
    console.log(typeof(a))
    a=parseInt(a,10)
    console.log(typeof(a))
    console.log(a+b)
    //console.log(dt.getDate());//1-31
    //console.log(dt.getMonth()+1);//0-11
    //console.log(dt.getFullYear());


    c="Your project deadline: "+(a+b)+"/"+(dt.getMonth()+1)+"/"+dt.getFullYear();
    document.getElementById("daysRemaining").innerHTML=c;

}
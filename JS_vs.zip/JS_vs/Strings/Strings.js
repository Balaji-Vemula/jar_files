console.log('HI')
//printing multilines on console along with whitespace
let multiLines=
`             This is a
             String which
             spans multiple lines
`
console.log(multiLines)

// comparing str to str, obj to obj and str to obj using == and ===
var name_str1='Balaji'
var name_str2='Balaji'
var name_obj1=new String('Balaji')
var name_obj2=new String('Balaji')

console.log(typeof(name_str1))
console.log(typeof(name_obj1))


console.log(name_str1==name_str2)
console.log(name_str1==name_obj1)
console.log(name_obj1==name_obj2)
console.log(name_obj1.valueOf()==name_obj2.valueOf())


console.log(name_str1===name_str2)
console.log(name_str1===name_obj1)
console.log(name_obj1===name_obj2)
console.log(name_obj1.valueOf()===name_obj2.valueOf())

//Some string functions
let empName='Jane Chang';
console.log(empName.length)
console.log(empName.indexOf('Ch'))
console.log(empName.search('Ch'))

// Slicing of string
var line='Fundamentals of JavaScript'
console.log(line.slice(1,12))
console.log(line.slice(-23,-15))
console.log(line.slice(13))

//replacing a string in a string
console.log(line.replace("JavaScript","Web Programming"))
console.log(line.replace("javascript","Python"))
console.log(line.replace(/javascript/i,"Python"))
console.log(line.replace("a",'A'))
console.log(line.replace(/a/g,'A'))

//split and trim functions
console.log(line.split(" "))

var myString='         Hey, This is JS           '
console.log(myString)
console.log(myString.trim())
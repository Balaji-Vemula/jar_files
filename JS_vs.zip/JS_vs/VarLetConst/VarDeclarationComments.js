"use strict";


var price1=5;
var price2=10;
var total=price1+price2;

console.log("sum of price1 and price2 is :", total);

// variables declared using var are allowed to be updated
price1=55;
price2=105;
total=price1+price2;

console.log("sum of price1 and price2 is :", total);


// variables declared using var are allowed to be redeclared
var price1=51;
var price2=101;
var total=price1+price2;

console.log("sum of price1 and price2 is :", total);


let p1=5;
let p2=10;
let t=p1+p2;

console.log("sum of price1 and price2 is :", t);

// variables declared using let are allowed to be updated
p1=45;
p2=120;
t=p1+p2;

console.log("sum of price1 and price2 is :", t);

// variables declared using let are not allowed to be redeclared
/*
let p1=52;
let p2=210;
let t=p1+p2;

console.log("sum of price1 and price2 is :", t);
*/

const MY_BIRTHDAY="18/08/1998";
console.log("The Birthday is :", MY_BIRTHDAY);

// variables declared using const are not allowed to be updated
/*
MY_BIRTHDAY="18/08/1998";
console.log("The Birthday is :", MY_BIRTHDAY);
*/

// variables declared using const are not allowed to be redeclared
/*
const MY_BIRTHDAY="18/08/1998";
console.log("The Birthday is :", MY_BIRTHDAY);
*/

/*
VARIABLE HOISTING: -
    variable hoisting is the declaration of a variable after it is declared and used.
*/

//Variable hoisting is possible using var keyword.
a=9;
a++;
console.log("The Value of a:",a);
var a;

//Variable hoisting is possible using let keyword.
/*
a=9;
console.log("The Value of a:",a);
let a;
*/

//Variable hoisting is possible using const keyword.
/*
a=9;
console.log("The Value of a:",a);
const a;
*/





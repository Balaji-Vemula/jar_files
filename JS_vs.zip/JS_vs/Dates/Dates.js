"use strict";

var time=new Date();
console.log(time);

time=new Date(2021, 2, 19,19,50,11);
console.log(time);

time=new Date("February 19, 2021");
console.log(time);

time=new Date("2021-02-19");
console.log(time);

time=new Date();
console.log("Offset minutes form GMT to this time zone"+time.getTimezoneOffset());

console.log("The UTC time is",time.toUTCString());


//console.log(Number(false))
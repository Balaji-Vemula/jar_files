console.log("14e4:",14e4);
console.log("14e-4:",14e-4);

console.log("20* '20'",20*'20');
console.log("'20'*20",'20'*20);

console.log("Infinity=",Infinity);
console.log("POSITIVE_INFINITY will return:",Number.POSITIVE_INFINITY);
console.log("1/0=",1/0);

console.log("NEGATIVE_INFINITY will return:",Number.NEGATIVE_INFINITY);
console.log("-1/0=",-1/0);

console.log("String divided by int=", "A string"/2);

console.log("Value of 0xEF",0xEF);

var num=16;

console.log("binary number of 16 is:",num.toString(2));
console.log(typeof num)
console.log(typeof num.toString(2));

var x=3.4567;
console.log(x.toFixed());
console.log(x.toFixed(2));
console.log(x.toFixed(5));

y=25.678;
console.log(y.toPrecision())
console.log(y.toPrecision(2))
console.log(y.toPrecision(5))


console.log(Number.MIN_SAFE_INTEGER)
console.log(Number.MIN_VALUE)
console.log(Number.MAX_SAFE_INTEGER)
console.log(Number.MAX_VALUE)
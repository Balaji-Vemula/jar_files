"use strict";

alert("This is an Alert message");

let n=prompt("The prompt message is: \nPlease enter your name:");
console.log("You have entered:",n);

let subject=prompt("Please enter your selected subject name:","JavaScript");
console.log("Your selected subject is "+subject);

let a=prompt("Enter a number to get its square value:");
let b=a*a;
alert("Square value of "+a+" is :"+b);
console.log("Square value of "+a+" is :"+b);

let output=confirm("Confirmation message: \n Ready to move to next demo:");
console.log(output)
if(output)
{
    console.log("You pressed ok");
}
else
{
    console.log("You pressed cancel");
}
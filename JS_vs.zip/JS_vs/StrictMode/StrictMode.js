"use strict";

var a= 30;
b=40; // Strict mode throws error at this line because the variable b should be declared before initialing

console.log("The value of a is %i and b is %i",a ,b);

var private = "just a String";// error- private is a reserved keyword
var undefined="A undefined value";// error- undefined value is reserved keyword and it is assigned to undefined

console.log("The private String is: ", private);
console.log("The undefined String is: ", undefined);
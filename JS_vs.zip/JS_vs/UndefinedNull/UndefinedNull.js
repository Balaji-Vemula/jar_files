"use strict";

var uninitialized_var;
console.log("The value of uninitialized_var:",uninitialized_var);

let uninitialized_let;
console.log("The value of uninitialized_let:",uninitialized_let);

var undefined_var=undefined;
console.log("The value of undefined_var:",undefined_var);

let undefined_let=undefined;
console.log("The value of undefined_let:",undefined_let);

const undefined_const=undefined;
console.log("The value of undefined_const:",undefined_const);

var null_var=null;
console.log("The value of null_var:",null_var);

let null_let=null;
console.log("The value of null_let:",null_let);

const null_const=null;
console.log("The value of null_const:",null_const);
document.getElementById("numericsection").innerHTML=30;

document.getElementById("textsection").innerHTML="Name : Balaji";


var a;

a=10;

//var b,c;

b=c=20;

x=a+30;

console.log('Value of a: '+a);
console.log('Value of b: '+b);
console.log('Value of c: '+c);
console.log('Value of x: '+x);

y=b*c;
console.log('Value of y: '+y);
n='Balaji';
console.log('The name is: %s',n);
console.log(`The name is: ${n}`);
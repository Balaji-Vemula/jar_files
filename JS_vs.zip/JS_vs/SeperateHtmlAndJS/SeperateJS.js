document.write("Hello world! This message is from the javascript file!");

console.log("Hello world! This message is from the js file and meant for \
the console!");
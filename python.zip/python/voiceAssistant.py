import speech_recognition as sr
import pyttsx3 as sk
import datetime
import pyjokes
import wikipedia
import pywhatkit as net

def talk(text):
    engine.say(text)
    engine.runAndWait()


listener=sr.Recognizer()
engine=sk.init()
voices=engine.getProperty('voices')
engine.setProperty('voice',voices[1].id)

def take_command():
    try:
        with sr.Microphone() as source:
            print("Listening...")
            voice= listener.listen(source)
            command=listener.recognize_google(voice)
            command=command.lower()
            print(command)
            if 'friday' in command:
                command=command.replace('friday','')
                return command
    except:
        pass

def run_alexa():
    command=take_command()
    if 'play' in command:
        
        song =command.replace('play','')
        print('Playing'+song)
        talk('Playing'+song)
        net.playonyt(song)
    elif 'time' in command:
        #time=datetime.datetime.now().strftime('%H:%M')
        time=datetime.datetime.now().strftime('%I:%M %p')
        print(time)
        talk(time)
    elif 'joke' in command:
        a=pyjokes.get_joke()
        print(a)
        talk(a)
    elif 'what is' or 'who is' in command:
        if 'what is ' in command:
            a=command.replace('what is','')
        elif 'who is ' in command:
            a=command.replace('who is','')
        #talk("From Google:")
        #net.info(a,2)
        talk("from wikipedia: ")
        info=wikipedia.summary(a,2)
        print("\nFrom Wikipedia:")
        print(info)
        talk(info)

run_alexa()

Python 3.9.1 (tags/v3.9.1:1e5d33e, Dec  7 2020, 17:08:21) [MSC v.1927 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
======= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py ======
Mohan
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
Mohan Naik
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
MohanNaik
>>> 2+4
6
>>> '2'+'4'
'24'
>>> a='2'
>>> type(a)
<class 'str'>
>>> chr(65)
'A'
>>> char(65)
Traceback (most recent call last):
  File "<pyshell#5>", line 1, in <module>
    char(65)
NameError: name 'char' is not defined
>>> chr(65)
'A'
>>> ord('A')
65
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
Mohan Naik56765
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
['mohan', 'balaji', 'sineeth', 'sandesh']
>>> names
'mohan,balaji,sineeth,sandesh'
>>> names[0]
'm'
>>> namelist[0]
'mohan'
>>> namelist[0][3]
'a'
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
Traceback (most recent call last):
  File "C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py", line 10, in <module>
    print(namelist)
NameError: name 'namelist' is not defined
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
['moh', 'n,b', 'l', 'ji,sineeth,s', 'ndesh']
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
['mohan', 'balaji', 'sineeth', 'sandesh']
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
['mohan', 'balaji', 'sineeth', 'sandesh']
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
['mohan', 'balaji', 'sineeth', 'sandesh']
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
mohan$balaji$sineeth$sandesh
['mohan', 'balaji', 'sineeth', 'sandesh']
>>> ji,sineeth,s
Traceback (most recent call last):
  File "<pyshell#12>", line 1, in <module>
    ji,sineeth,s
NameError: name 'ji' is not defined

>>> 
>>> 
>>> 
>>> a='mohannaik nenavath'
>>> a.capitalize()
'Mohannaik nenavath'
>>> a.upper()
'MOHANNAIK NENAVATH'
>>> a.lower()
'mohannaik nenavath'
>>> a.upper()
'MOHANNAIK NENAVATH'
>>> a.casefold()
'mohannaik nenavath'
>>> b='BaLaJi'
>>> b
'BaLaJi'
>>> b.swapcase()
'bAlAjI'
>>> a
'mohannaik nenavath'
>>> a.capitalize()
'Mohannaik nenavath'
>>> a.title()
'Mohannaik Nenavath'
>>> c="    hello    "
>>> c
'    hello    '
>>> c.strip()
'hello'
>>> c
'    hello    '
>>> c=c.strip()
>>> c
'hello'
>>> d="hello Mohan"
>>> d
'hello Mohan'
>>> d=d.strip()
>>> d
'hello Mohan'
>>> d=" "+d+" "
>>> d
' hello Mohan '
>>> d.stript()
Traceback (most recent call last):
  File "<pyshell#41>", line 1, in <module>
    d.stript()
AttributeError: 'str' object has no attribute 'stript'
>>> d.strip()
'hello Mohan'
>>> d="   Hello       Mohan     "
>>> f
Traceback (most recent call last):
  File "<pyshell#44>", line 1, in <module>
    f
NameError: name 'f' is not defined
>>> d
'   Hello       Mohan     '
>>> d.strip()
'Hello       Mohan'
>>> d.startswith('H')
False
>>> d
'   Hello       Mohan     '
>>> d=d.strip()
>>> d
'Hello       Mohan'
>>> d.startswith('He')
True
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
['Thank you for the music', 'Welcome to the jungle']
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
['Thank you for the music. Welcome to the jungle']
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
Traceback (most recent call last):
  File "C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py", line 16, in <module>
    x = txt.splitlines('.')
TypeError: an integer is required (got type str)
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
['Thank you for the music. Welcome to the jungle']
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
['Thank you for the music. Welcome to the jungle']
>>> l=[3,54,6,343,34,3,3,3,3,3]
>>> l.index(3)
0
>>> l.rindex(3)
Traceback (most recent call last):
  File "<pyshell#54>", line 1, in <module>
    l.rindex(3)
AttributeError: 'list' object has no attribute 'rindex'
>>> str='mohannaik'
>>> str.index('n')
4
>>> str.rindex('n')
5
>>> str=str+"nenavath"
>>> str
'mohannaiknenavath'
>>> str.rindex('n')
11
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
mohan$balaji$sineeth$sandesh
['mohan', 'balaji', 'sineeth', 'sandesh']
mohan&balaji&sineeth&sandesh
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
mohan$balaji$sineeth$sandesh
['mohan', 'balaji', 'sineeth', 'sandesh']
mohan& balaji& sineeth& sandesh
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
mohan$balaji$sineeth$sandesh
['mohan', 'balaji', 'sineeth', 'sandesh']
mohan+balaji+sineeth+sandesh
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
b'Mohan'
Mohan
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
b'Mohan naik nenavath'
Mohan naik nenavath
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
b'Moh\xc3\xa5n n\xc3\xa5ik nen\xc3\xa5v\xc3\xa5th'
Mohån nåik nenåvåth
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
Traceback (most recent call last):
  File "C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py", line 27, in <module>
    print(x)
NameError: name 'x' is not defined
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
Traceback (most recent call last):
  File "C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py", line 29, in <module>
    print(x.decode())
NameError: name 'x' is not defined
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
  banana  
>>> 
= RESTART: C:\Users\balaji.vemula\OneDrive - Trianz\Desktop\test.py
       banana       
>>> 
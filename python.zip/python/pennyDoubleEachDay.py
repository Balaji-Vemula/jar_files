n=int(input('Enter no of days: '))
p=1
for i in range(n):
    print(p)
    p=2*p

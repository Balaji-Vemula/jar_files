'''
input: tv switch tv switch tv switch tv switch tv switch tv switch tv switch tv switch

output: ['tv', 'switch', 'tv1', 'switch1', 'tv2', 'switch2', 'tv3', 'switch3', 'tv4', 'switch4', 'tv5', 'switch5', 'tv6', 'switch6', 'tv7', 'switch7']
'''
def deviceNamesSystem(devicenames):

    #write your code here
    devicenames.reverse()
    l=list(set(devicenames))
    for i in l:
        y=None
        z=devicenames.count(i)
        for k in range(1,z):
            y=devicenames.index(i)
            devicenames[y]=devicenames[y]+str((z-k))
    devicenames.reverse()
    return devicenames



    
    








j=[x for x in input().split()]

print(deviceNamesSystem(j))

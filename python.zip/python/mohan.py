'''
s=input()
l=list(set(s))
l.sort()
x=''
for i in l:
    x=x+i
    x=x+str(s.count(i))
print(x)
'''










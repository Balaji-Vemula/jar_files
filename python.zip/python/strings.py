'''
str='Mohan'

str=str+" Naik56765"
print(str)


names="mohan$balaji$sineeth$sandesh"
print(names)
name=names.split('$')
print(name)
z='+'.join(name)
print(z)


txt = "Thank you for the music.\nWelcome to the jungle"

x = txt.splitlines()

print(x)

txt = "Mohån nåik nenåvåth"

x = txt.encode()
print(x)
print(x.decode())
'''


txt = "banana"

x = txt.center(20)       

print(x)

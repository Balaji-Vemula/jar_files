t=int(input())
for i in range(t):
    s=input()
    b=s[0]
    for i in range(len(s)):
        if s[i]!=b[-1]:
            b=b+s[i]
        
    print(b)
'''
no same char should be together
o/p:
3 #number of testcases
abb
ab
aaab
ab
ababa
ababa
'''
t=int(input())
l=[int(x) for x in input().split()]
if len(l)!=len(set(l)) or max(l)>t or (l==sorted(l)):
   print('Bad')
else:
    print('Good')

'''
prints bad if there are duplicate or list is in sorted order or if the max value of the list is more than len(l)

'''

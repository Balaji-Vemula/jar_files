import pyttsx3

import PyPDF3
file = open('Rupa.pdf', 'rb')
reader = PyPDF3.PdfFileReader(file)
print(reader.numPages)
page1 = reader.getPage(11)
pdfData=page1.extractText()
print(pdfData)
text="Balaji Vemula"
speaker=pyttsx3.init()
print(text)
speaker.say("Hello"+text)
speaker.runAndWait()

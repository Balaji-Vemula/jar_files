from pytube import YouTube  
video_url = 'https://www.youtube.com/watch?v=Lpgsk-4VtDE'   
youtube = YouTube(video_url)  
video = youtube.streams.get_highest_resolution()  
video.download('C:/Users/balaji.vemula/Downloads/')

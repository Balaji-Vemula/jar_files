import pyttsx3
speaker=pyttsx3.init()
speaker.say("Hello Sandesh and SaiKrishna, How are guys doing today?")
speaker.runAndWait()

import pywhatkit as wa
def sendmessage(n, mg, h=None, m=None):
    if(not h and not m):
        import time
        t = time.localtime()
        h = int(time.strftime("%H", t))
        m=int(time.strftime("%M",t))+1
    elif( (not h and m) or (h and not m)):
        print(" please provide hours and minutes")
    n='+91'+n
    wa.sendwhatmsg(n,mg,h,m)

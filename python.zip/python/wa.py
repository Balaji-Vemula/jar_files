import pywhatkit as wa
'''
wa.sendwhatmsg('+917989436297', 'hello bro',12,40)
import time
t = time.localtime()
ch = time.strftime("%H", t)
cm=time.strftime("%M",t)
print(int(ch),":",int(cm)+2)
'''
def sendmessage(n, mg, h=None, m=None):
    if(not h and not m):
        import time
        t = time.localtime()
        h = int(time.strftime("%H", t))
        m=int(time.strftime("%M",t))+2
    elif( (not h and m) or (h and not m)):
        print(" please provide hours and minutes")
    n='+91'+n
    wa.sendwhatmsg(n,mg,h,m)


    
n=input()
mg=input()
sendmessage(n,mg)

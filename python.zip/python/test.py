
'''
l=[]
n=int(input('Enter a limit: '))

for i in range(n):
    l.append(int(input()))



l=[x for x in input().split(',')]

'''
l=[]


r=int(input('Enter rows: '))
c=int(input('Enter columns: '))

for i in range(r):
    t=[]
    for j in range(c):
        t.append(int(input()))
    l.append(t)
